<?php get_header( ) ; ?>

<?php get_template_part( 'questionlist/coordinategeometrylist' ); ?>


<?php get_footer(); ?>