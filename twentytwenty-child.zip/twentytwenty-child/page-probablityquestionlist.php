<?php get_header(  ) ; ?>

<?php get_template_part( 'questionlist/probablityandstatisticslist' ); ?>


<?php get_footer(); ?>