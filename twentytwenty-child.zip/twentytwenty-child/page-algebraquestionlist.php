<?php get_header( ) ; ?>

<?php get_template_part( 'questionlist/algebralist' ); ?>


<?php get_footer(); ?>