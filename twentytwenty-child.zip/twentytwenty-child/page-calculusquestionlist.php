<?php get_header(  ) ; ?>

<?php get_template_part( 'questionlist/calculuslist' ); ?>


<?php get_footer(); ?>